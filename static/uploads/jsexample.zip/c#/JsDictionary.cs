﻿using Microsoft.ClearScript;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace jsExample {
    /// <summary>
    /// Default implementation of IPropertyBag (ClearScript). 
    /// You can access the internal dictionary in the common JavaScript dot and bracket notation
    /// </summary>
    public class JsDictionary : IPropertyBag {
        private Dictionary<string, object> dict = new Dictionary<string, object>();

        /// <summary>
        /// Adds the value object to the dictionary with given key
        /// </summary>
        /// <param name="key">Key of the property</param>
        /// <param name="value">Value to put in de dictionary</param>
        public void Add(string key, object value) {
            dict[key] = value;
        }

        /// <summary>
        /// Returns true of the dictionary contains given key
        /// </summary>
        /// <param name="key"></param>
        /// <returns></returns>
        public bool ContainsKey(string key) {
            return dict.ContainsKey(key);
        }

        /// <summary>
        /// Returns a collection of all Keys in the dictionary
        /// </summary>
        public ICollection<string> Keys {
            get { return dict.Keys; }
        }

        /// <summary>
        /// Removes a entry in the dictionary with given key
        /// </summary>
        /// <param name="key">Key to remove from the dictionary</param>
        /// <returns></returns>
        public bool Remove(string key) {
            return dict.Remove(key);
        }

        /// <summary>
        /// Tries to get the value
        /// </summary>
        /// <param name="key">Key fothe value you are trying to get</param>
        /// <param name="value">Output value of the given key</param>
        /// <returns>Boolean whenever or not the key existed</returns>
        public bool TryGetValue(string key, out object value) {
            return dict.TryGetValue(key, out value);
        }

        /// <summary>
        /// Returns all value objects within the dictionary
        /// </summary>
        public ICollection<object> Values {
            get { return dict.Values; }
        }

        /// <summary>
        /// Default getter and setter which returns the value object on given key within the dictionary
        /// </summary>
        /// <param name="key">Key of the value to get</param>
        /// <value>The value to set on given key</value>
        /// <returns>Value object of given key</returns>
        public virtual object this[string key] {
            get {
                return dict[key];
            }
            set {
                dict[key] = value;
            }
        }

        /// <summary>
        /// Adds the KeyValuePair to the dictionary.
        /// </summary>
        /// <param name="item">Item to add</param>
        public void Add(KeyValuePair<string, object> item) {
            dict.Add(item.Key, item.Value);
        }

        /// <summary>
        /// Clears the whole dictionary
        /// </summary>
        public void Clear() {
            dict.Clear();
        }

        /// <summary>
        /// Returns the boolean whenever or not the given keyvaluepair is present in the dictionary
        /// </summary>
        /// <param name="item">Item to check the presence of</param>
        /// <returns>Boolean, if true te item is present, if false it isn't</returns>
        public bool Contains(KeyValuePair<string, object> item) {
            return dict.Contains(item);
        }

        /// <summary>
        /// Copies all values in the array. NOT IMPLEMENTED
        /// </summary>
        /// <param name="array">Output array</param>
        /// <param name="arrayIndex">Starting on given index</param>
        public void CopyTo(KeyValuePair<string, object>[] array, int arrayIndex) { }

        /// <summary>
        /// Returns the count of items present in the dictionary
        /// </summary>
        public int Count { get { return dict.Count; } }

        /// <summary>
        /// Dictionary is never readonly
        /// </summary>
        public bool IsReadOnly { get { return false; } }

        /// <summary>
        /// Removes given KeyValuePair.
        /// </summary>
        /// <param name="item">Item to delete</param>
        /// <returns>Whenever or not the value got deleted or wasn't present in the first place</returns>
        public bool Remove(KeyValuePair<string, object> item) {
            if (dict.Contains(item))
                return dict.Remove(item.Key);
            return false;
        }

        /// <summary>
        /// Gets the enumerator
        /// </summary>
        /// <returns>Enumerator of all key value pairs</returns>
        public IEnumerator<KeyValuePair<string, object>> GetEnumerator() {
            return dict.GetEnumerator();
        }

        /// <summary>
        /// Gets the enumerator
        /// </summary>
        /// <returns>Enumerator of all key value pairs</returns>
        System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator() {
            return dict.GetEnumerator();
        }
    }
}