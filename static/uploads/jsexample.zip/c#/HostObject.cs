﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace jsExample {
    /// <summary>
    /// Used to communicate between script and C#
    /// </summary>
    public class HostObject {
        public JsDictionary input = new JsDictionary();
        public JsDictionary output = new JsDictionary();
    }
}
