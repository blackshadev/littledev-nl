﻿(function () {
    var emailRegex_str = "[-0-9a-zA-Z.+_]+@[-0-9a-zA-Z.+_]+\.[a-zA-Z]{2,4}";
    var email_re = new RegExp(emailRegex_str);

    var arr = JSON.parse(host.input.json);

    var valid = 0;
    var invalid = 0;
    var totalRating = 0;


    for (var i = 0; i < arr.length; i++) {
        totalRating += arr[i].rating;

        var isValid = email_re.test(arr[i]["email"]);
        if (isValid)
            valid++;
        else
            invalid++;

    }

    host.output.valid = valid;
    host.output.invalid = invalid;
    host.output.totalRating = totalRating;
})();