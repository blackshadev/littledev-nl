﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.ClearScript.V8;

namespace jsExample {

    class Program {
        
        public static HostObject HostObj = new HostObject();
        public static readonly string BaseDir = AppDomain.CurrentDomain.BaseDirectory + @"\..\..\";

        static void Main(string[] args) {
            HostObject HostObj = new HostObject();

            // Set input json
            HostObj.input["json"] = File.ReadAllText(BaseDir + @"\input.json");
            // The script as a string
            string script = File.ReadAllText(BaseDir + @"\script.js");
            
            // Running the script
            using (var engine = new V8ScriptEngine()) {
                engine.AddHostObject("host", HostObj);
                engine.AddHostType("Console", typeof(Console));

                engine.Execute(script);
            }

            // Outputting the script
            double average = (double)(int)HostObj.output["totalRating"] / ((int)HostObj.output["invalid"] + (int)HostObj.output["valid"]);
            Console.WriteLine("Got {0} invalid email adresses", HostObj.output["invalid"]);
            Console.WriteLine("Got {0} valid email adresses", HostObj.output["valid"]);
            Console.WriteLine("Total average rating {0:g}", average);
            Console.ReadLine(); 
        }

    }

}
