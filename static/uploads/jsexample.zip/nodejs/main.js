(function() {
    var fs = require("fs");
    var vm = require("vm");

    // setup execution environment
    var env = {
        host: {
            input: {},
            output: {}
        }
    };

    // fill with json
    env.host.input.json = fs.readFileSync("input.json");
    var script = fs.readFileSync("script.js");

    // Run the script
    vm.runInNewContext(script, env);

    // Output
    var out = env.host.output;
    var avg = out.totalRating / (out.invalid + out.valid);
    console.log("Got " + out.invalid + " invalid email adresses");
    console.log("Got " + out.valid + " valid email adresses");
    console.log("Total average rating " + avg);
})();