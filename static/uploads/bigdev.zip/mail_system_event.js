var sys = require('sys')
var exec = require('child_process').exec;
var format = require('util').format;
var child;
var date_re = new RegExp("Date and Time\s:\s([a-zA-Z0-9: ]*)", "gm");
var subj_re = new RegExp("Description\s:\s([a-zA-Z0-9: ]*)", "mg");
var from = "server@littledev.nl";
var to   = "info@littledev.nl";
var sendEmail = "/opt/scripts/sendEmail"

child = exec("/opt/dell/srvadmin/bin/omreport system alertlog | tail -n 50", function(err, stdout, stderr) {
    var blocks = stdout.split("\n\n");
    blocks.shift(); // remove first
    blocks.reverse();
    blocks.shift(); // remove last (only an enter)
    var date = blocks[0].match(/Date and Time\s*:\s*([a-zA-Z0-9: ]*)/)[1];
    var desc = blocks[0].match(/Description\s*:\s*([a-zA-Z0-9: ]*)/)[1];
    
    var message = "Server event\n---------\n" + blocks[0];
    
    var args = format("-f \"%s\" -t \"%s\" -u \"%s\" -m \"%s\" -o tls=no ", from, to, desc, message);
    exec(sendEmail + " " + args, function(err, stdout, stderr) {
        if(err)
            console.log(stderr);
    });
});